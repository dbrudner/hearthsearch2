export enum heroes {
	warrior = "#7c0006",
	hunter = "#cdc450",
	mage = "#3695f9",
	druid = "#668a52",
	paladin = "#bf9742",
	priest = "#a5a5a5",
	rogue = "#316661",
	shaman = "#122c72",
	warlock = "#46007c"
}

export enum rarities {
	common = "gray",
	rare = "rgba(83, 86, 255, 0.651)",
	epic = "#AC0CE8",
	legendary = "#E85800"
}
