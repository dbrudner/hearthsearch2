import { Logout } from "../user/logout";

export const Navbar = () => (
	<div>
		<Logout />
	</div>
);
