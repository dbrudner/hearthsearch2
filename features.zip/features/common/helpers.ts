export const capitalize = string =>
	string.charAt(0) + string.substr(1).toLowerCase();
